import IFPy


class PC:

     def __init__(self):
         self.ifu = IFPy.IF()
         nextInstAddr = 96

     def connection(self, ifu):
         self.ifu = ifu