import IssueUnit
import MEMUNIT
from queue import Queue

class PreMem:

    def __init__(self):
        self.isstalled = False
        self.queue = Queue(2)
        self.issueunit = IssueUnit.IssueUnit()
        self.memunit = MEMUNIT

    def connect(self, memu, isu):
        self.issueunit = isu
        self.MEMUNIT = memu

    def getinstruction(self):
        if self.queuesize > 0:
            put(hold)
            self.queue.remove(hold)
        return hold
        # if len(self.queue) > 0:
          # hold = self.queue[0]
          # self.queue.remove(hold)
        # return hold

    def addinstruction(self, e):
        if len(self.queue) == 2:
            self.isstalled = True  # opt
        else:
            self.queue.append(e)

    def isprememfull(self):
        if len(self.queue) == 2:
            return True
        else:
            return False
