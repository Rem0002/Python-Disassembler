from helpers import SetUp
import masking_constants as masks
import sys
from Registers import registers


class Disassembler:
    opcodeStr = []
    instrSpaced = []
    arg1 = []
    arg2 = []
    arg3 = []
    arg1Str = []
    arg2Str = []
    arg3Str = []
    dataval = []
    rawdata = []
    address = []
    numInstructs = 0

    def __init__(self):  # just bring them all in here so I can self.xxxmask and not MASKs.xxxmask
        self.masking_constants = masks
        self.bMask = masks.bMask
        self.jAddrMask = masks.jAddrMask
        self.specialMask = masks.specialMask
        self.rnMask = masks.rnMask
        self.rmMask = masks.rmMask
        self.rdMask = masks.rdMask
        self.imMask = masks.imMask
        self.shmtMask = masks.shmtMask
        self.addrMask = masks.addrMask
        self.addr2Mask = masks.addr2Mask
        self.imsftMask = masks.imsftMask
        self.imdataMask = masks.imdataMask

    @property
    def run(self, opcode=[]):
        if not opcode:
            instructions = SetUp.import_data_file()
            outputfilename = SetUp.get_output_filename()

            print("raw output filename is ", outputfilename)

            for i in instructions:
                if self.opcodeStr[i] < 160 or self.opcodeStr[i] > 191:
                    self.address.append(96 + (i * 4))

            for z in instructions:
                opcode.append(int(z, base=2) >> 21)

        for i in opcode:
            self.numInstructs = self.numInstructs + 1
            if opcode[i] == 1112:
                # ADD R
                self.instrSpaced.append(SetUp.bin2StringSpacedR(instructions[i]))  # why is this a problem?
                self.opcodeStr.append("ADD")
                # arg1 = (int(opcode[i], base=2) & self.rnMask) >> 5
                # arg2 = registers[f'r{(int(opcode[i], base=2) & self.rmMask) >> 16}']
                # arg3 = registers[f'r{(int(opcode[i], base=2) & self.rdMask) >> 0}']
                # sum = arg2 + arg3
                self.arg1.append((int(instructions[i], base=2) & self.rnMask) >> 5)
                self.arg2.append((int(instructions[i], base=2) & self.rmMask) >> 16)
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append(", R" + str(self.arg1[i]))
                self.arg3Str.append(", R" + str(self.arg2[i]))
                # result = (f'r{arg1}', sum)
            elif opcode[i] == 1624:
                # SUB R
                self.instrSpaced.append(SetUp.bin2StringSpacedR(instructions[i]))
                self.opcodeStr.append("SUB")
                # arg1 = ((int(instructions[i], base=2) & self.rnMask) >> 5)
                # arg2 = ((int(instructions[i], base=2) & self.rmMask) >> 16)
                # arg3 = ((int(instructions[i], base=2) & self.rdMask) >> 0)
                # difference = arg2 - arg3
                self.arg1.append((int(instructions[i], base=2) & self.rnMask) >> 5)
                self.arg2.append((int(instructions[i], base=2) & self.rmMask) >> 16)
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append(", R" + str(self.arg1[i]))
                self.arg3Str.append(", R" + str(self.arg2[i]))
                # return f'r{arg1}', difference
            elif opcode[i] == 1104:
                # AND R
                self.instrSpaced.append(SetUp.bin2StringSpacedR(instructions[i]))
                self.opcodeStr.append("AND")
                # arg1 = ((int(instructions[i], base=2) & self.rnMask) >> 5)
                # arg2 = ((int(instructions[i], base=2) & self.rmMask) >> 16)
                # arg3 = ((int(instructions[i], base=2) & self.rdMask) >> 0)
                # conjunction = arg2 & arg3
                self.arg1.append((int(instructions[i], base=2) & self.rnMask) >> 5)
                self.arg2.append((int(instructions[i], base=2) & self.rmMask) >> 16)
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append(", R" + str(self.arg1[i]))
                self.arg3Str.append(", R" + str(self.arg2[i]))
                # return f'r{arg1}', conjunction
            elif 1160 <= opcode[i] <= 1161:
                # ADDI I
                self.instrSpaced.append(SetUp.bin2StringSpacedI(instructions[i])) # clarify this with tutor
                self.opcodeStr.append("ADDI")
                # arg1 = ((int(instructions[i], base=2) & self.imMask) >> 10)
                # arg2 = ((int(instructions[i], base=2) & self.rnMask) >> 5)
                # arg3 = ((int(instructions[i], base=2) & self.rdMask) >> 0)
                # sum2 = registers[arg2] + arg3
                self.arg1.append((int(instructions[i], base=2) & self.rnMask) >> 10)
                self.arg2.append((int(instructions[i], base=2) & self.rmMask) >> 5)
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append(", R" + str(self.arg2[i]))
                self.arg3Str.append(", #" + str(self.arg1[i]))
                # return f'{arg1}', sum2  # does this add the register in arg2 with the immediate in arg3?
            elif opcode[i] == 1360:
                # ORR R
                self.instrSpaced.append(SetUp.bin2StringSpacedR(instructions[i]))
                self.opcodeStr.append("ORR")
                # arg1 = ((int(instructions[i], base=2) & self.rnMask) >> 5)
                # arg2 = ((int(instructions[i], base=2) & self.rmMask) >> 16)
                # arg3 = ((int(instructions[i], base=2) & self.rdMask) >> 0)
                # disjoint = arg2 | arg3
                self.arg1.append((int(instructions[i], base=2) & self.rnMask) >> 10)
                self.arg2.append((int(instructions[i], base=2) & self.rmMask) >> 5)
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append(", R" + str(self.arg1[i]))
                self.arg3Str.append(", R" + str(self.arg2[i]))
                # return f'{arg1}', disjoint
            elif 1440 <= opcode[i] <= 1447:
                # CBZ CB
                self.instrSpaced.append(SetUp.bin2StringSpacedCB(instructions[i]))
                self.opcodeStr.append("CBZ")
                self.arg1.append(
                    SetUp.imm_bit_to_32_bit_converter(((int(instructions[i], base=2) & self.addr2Mask) >> 5), 19))
                self.arg2.append(0)
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append("")
                self.arg3Str.append(", #" + str(self.arg1[i]))
            elif 1448 <= opcode[i] <= 1455:
                # CBNZ CB
                self.instrSpaced.append(SetUp.bin2StringSpacedCB(instructions[i]))
                self.opcodeStr.append("CBNZ")
                self.arg1.append(
                    SetUp.imm_bit_to_32_bit_converter(((int(instructions[i], base=2) & self.addr2Mask) >> 5), 19))
                self.arg2.append(0)
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append("")
                self.arg3Str.append(", #" + str(self.arg1[i]))
            elif 1672 <= opcode[i] <= 1673:
                # SUBI I
                self.instrSpaced.append(SetUp.bin2StringSpacedI(instructions[i]))
                self.opcodeStr.append("SUBI")
                # arg1 = ((int(instructions[i], base=2) & self.imMask) >> 10)
                # arg2 = ((int(instructions[i], base=2) & self.rnMask) >> 5)
                # arg3 = ((int(instructions[i], base=2) & self.rdMask) >> 0)
                # immdiff = registers[arg2] - arg3
                self.arg1.append((int(instructions[i], base=2) & self.rnMask) >> 10)
                self.arg2.append((int(instructions[i], base=2) & self.rmMask) >> 5)
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append(", R" + str(self.arg2[i]))
                self.arg3Str.append(", #" + str(self.arg1[i]))
                # return f'{arg1}', immdiff
            elif 1684 <= opcode[i] <= 1687:
                # MOVZ IM
                self.instrSpaced.append(SetUp.bin2StringSpacedIM(instructions[i]))
                self.opcodeStr.append("MOVZ")
                # arg1 = (((int(instructions[i], base=2) & self.imsftMask) >> 21) * 16)
                # arg2 = SetUp.imm_bit_to_32_bit_converter(((int(instructions[i], base=2) & self.imdataMask) >> 5), 16)
                # arg3 = (int(instructions[i], base=2) & self.rdMask) >> 0
                # x = [format(arg2, 'b')]
                self.arg1.append(((int(instructions[i], base=2) & self.imsftMask) >> 21) * 16)
                self.arg2.append(
                    SetUp.imm_bit_to_32_bit_converter(((int(instructions[i], base=2) & self.imdataMask) >> 5), 16))
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append(", " + str(self.arg2[i]))
                self.arg3Str.append(", LSL " + str(self.arg1[i]))
                # if arg3 == 0:
                    # shiftz = (['0'] * (32 - len(x))).append(*x)
                # else:
                    # shiftz = (['0'] * (16 - len(x))).append(*x)
                    # shiftz.append(['0'] * 16)
                # eturn f'{arg1}', shiftz
            elif 1940 <= opcode[i] <= 1943:
                # MOVK IM
                self.instrSpaced.append(SetUp.bin2StringSpacedIM(instructions[i]))
                self.opcodeStr.append("MOVK")
                self.arg1.append(((int(instructions[i], base=2) & self.imsftMask) >> 21) * 16)
                self.arg2.append(
                    SetUp.imm_bit_to_32_bit_converter(((int(instructions[i], base=2) & self.imdataMask) >> 5), 16))
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append(", " + str(self.arg2[i]))
                self.arg3Str.append(", LSL " + str(self.arg1[i]))

                # TODO figure out how to derive a result for the MOVK/MOVZ operations
            elif opcode[i] == 1690:
                # LSR R
                self.instrSpaced.append(SetUp.bin2StringSpacedR(instructions[i]))
                self.opcodeStr.append("LSR")
                self.arg1.append((int(instructions[i], base=2) & self.rnMask) >> 5)
                self.arg2.append(
                    SetUp.imm_bit_to_32_bit_converter(((int(instructions[i], base=2) & self.shmtMask) >> 10), 6))
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append(", R" + str(self.arg1[i]))
                self.arg3Str.append(", #" + str(self.arg2[i]))
            elif opcode[i] == 1691:
                # LSL R
                self.instrSpaced.append(SetUp.bin2StringSpacedR(instructions[i]))
                self.opcodeStr.append("LSL")
                self.arg1.append((int(instructions[i], base=2) & self.rnMask) >> 5)
                self.arg2.append(
                    SetUp.imm_bit_to_32_bit_converter(((int(instructions[i], base=2) & self.shmtMask) >> 10), 6))
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append(", R" + str(self.arg1[i]))
                self.arg3Str.append(", #" + str(self.arg2[i]))
                # TODO handle result for LSR/LSL/ASR
            elif opcode[i] == 1984:
                # STUR D
                self.instrSpaced.append(SetUp.bin2StringSpacedD(instructions[i]))
                self.opcodeStr.append("STUR")
                self.arg1.append((int(instructions[i], base=2) & self.rnMask) >> 5)
                self.arg2.append(
                    SetUp.imm_bit_to_32_bit_converter(((int(instructions[i], base=2) & self.addrMask) >> 12), 9))
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append(", [R" + str(self.arg1[i]))
                self.arg3Str.append((", #" + str(self.arg2[i])) + "]")
            elif opcode[i] == 1986:
                # LDUR D
                self.instrSpaced.append(SetUp.bin2StringSpacedD(instructions[i]))
                self.opcodeStr.append("LDUR")
                self.arg1.append((int(instructions[i], base=2) & self.rnMask) >> 5)
                self.arg2.append(
                    SetUp.imm_bit_to_32_bit_converter(((int(instructions[i], base=2) & self.addrMask) >> 12), 9))
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append(", [R" + str(self.arg1[i]))
                self.arg3Str.append((", #" + str(self.arg2[i])) + "]")
            elif opcode[i] == 1692:
                # ASR R
                self.instrSpaced.append(SetUp.bin2StringSpacedR(instructions[i]))
                self.opcodeStr.append("ASR")
                self.arg1.append((int(instructions[i], base=2) & self.rnMask) >> 5)
                self.arg2.append(
                    SetUp.imm_bit_to_32_bit_converter(((int(instructions[i], base=2) & self.shmtMask) >> 10), 6))
                self.arg3.append((int(instructions[i], base=2) & self.rdMask) >> 0)
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append(", R" + str(self.arg1[i]))
                self.arg3Str.append(", #" + str(self.arg2[i]))
            elif opcode[i] == 1872:
                # EOR R
                self.instrSpaced.append(SetUp.bin2StringSpacedR(instructions[i]))
                self.opcodeStr.append("EOR")
                arg1 = ((int(instructions[i], base=2) & self.rnMask) >> 5)
                arg2 = ((int(instructions[i], base=2) & self.rmMask) >> 16)
                arg3 = ((int(instructions[i], base=2) & self.rdMask) >> 0)
                bitor = registers[arg2] ^ registers[arg3]
                self.arg1Str.append("\tR" + str(self.arg3[i]))
                self.arg2Str.append(", R" + str(self.arg1[i]))
                self.arg3Str.append(", R" + str(self.arg2[i]))
                return f'{arg1}', bitor
            elif opcode[i] == 0:
                # NOP 0x00000000
                self.instrSpaced.append(SetUp.bin2StringSpaced(instructions[i]))
                self.opcodeStr.append("NOP")
                self.arg1.append(0)
                self.arg2.append(0)
                self.arg3.append(0)
                self.arg1Str.append("")
                self.arg2Str.append("")
                self.arg3Str.append("")
            # B
            elif 160 <= opcode[i] <= 191:
                self.instrSpaced.append(SetUp.bin2StringSpacedB(instructions[i]))
                self.opcodeStr.append("B")
                self.arg1.append(
                    SetUp.imm_bit_to_32_bit_converter(((int(instructions[i], base=2) & self.bMask) >> 0), 26))
                self.arg2.append(0)
                self.arg3.append(0)
                self.arg1Str.append("\t#" + str(self.arg1[i]))
                self.arg2Str.append("")
                self.arg3Str.append("")
            # provided break code
            elif opcode[i] == 2038 and (int(instructions[i], base=2) & self.specialMask) == 2031591:
                self.instrSpaced.append(SetUp.bin2StringSpaced(instructions[i]))
                self.opcodeStr.append("BREAK")
                self.arg1.append(0)
                self.arg2.append(0)
                self.arg3.append(0)
                self.arg1Str.append("")
                self.arg2Str.append("")
                self.arg3Str.append("")
                print("breaking")
                break
            else:
                self.opcodeStr.append("unknown")
                self.arg1.append(0)
                self.arg2.append(0)
                self.arg3.append(0)
                self.arg1Str.append("")
                self.arg2Str.append("")
                self.arg3Str.append("")
                print("i =:  " + str(i))
                print("opcode =:    " + str(opcode[i]))
                sys.exit("You have found an unknown instruction, investigate NOW")

        count = 0
        for k in range(len(instructions)):
            count += 1
            if count > self.numInstructs:
                self.rawdata.append(instructions[k])
                self.dataval.append(SetUp.imm_bit_to_32_bit_converter((int(instructions[k], base=2)), 32))
        return {
            "opcode": opcode,
            "opcodeStr": self.opcodeStr,
            "arg1": self.arg1,
            "arg1Str": self.arg1Str,
            "arg2": self.arg2,
            "arg2Str": self.arg2Str,
            "arg3": self.arg3,
            "arg3Str": self.arg3Str,
            "result": result,
            "dataval": self.dataval,
            "address": self.address,
            "numInstructs": self.numInstructs
        }

    def print(self):

        outFile = open(SetUp.get_output_filename() + "_dis.txt", 'w')
        count = 0
        for p in range(self.numInstructs):
            outFile.write(
                str(self.instrSpaced[p]) + '\t' + str(self.address[p]) + '\t' + self.opcodeStr[p] + self.arg1Str[p] +
                self.arg2Str[p] + self.arg3Str[p] + '\n')
            count += 1

        for p in range(len(self.dataval)):
            outFile.write(
                str(self.rawdata[p]) + '\t' + str(self.address[p + count]) + '\t' + str(self.dataval[p]) + '\n')

        outFile.close()
