import WB
import ALU


class PostALU:
    def __init__(self):
        self.entry = []
        self.max_entry = 1
        self.designation_register = 0
        self.result = ""
        self.alu = ALU.ALU()
        self.wb = WB.WBUnit()

    def connection(self, wb, al):
        self.wb = wb
        self.alu = al

    def push(self, data):  # use tuples to hold the result and destination register
        if not self.entry:
            self.entry.append(data)

    def pull(self):
        if self.entry:
            return self.entry.pop()


postAlu = PostALU()
