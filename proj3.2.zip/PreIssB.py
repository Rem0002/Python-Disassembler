import IFPy
import disassembler

InstructionList = []


class PreIssueBuffer:

    def __init__(self):
        self.prebuffer_entries = []
        self.prebuffer_limit = 4
        self.clockcycle = 0
        self.IFetch = self.IFPy.IF()
        self.issueunit = IssueUnit.IssueUnit

    def connect(self, ifet, isn):
        self.IFetch = ifet
        self.issueunit = isn

    def __fill_prebuffer(self, instruction):
        self.prebuffer_entries.append(instruction)

    def check_prebuffer(self):
        if len(self.prebuffer_entries) > self.prebuffer_limit:
            return False
        else:
            return True

    def Availableprebuffer(self):
        return self.prebuffer_limit - len(self.prebuffer_entries)

    def IssueInstruction(self):
        hold = self.prebuffer_entries[0]
        self.prebuffer_entries.remove(hold)
        return hold

    def addprebuffer(self, instruction):
        if self.check_prebuffer():
            if instruction.opcode:
                self.prebuffer_entries.append(instruction)

    def disassemble(self):
        opcodes = dissasembler.run()
