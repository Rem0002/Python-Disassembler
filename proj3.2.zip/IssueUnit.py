import PreIssB
import PreMem
import PreAlu

class IssueUnit:

    def __init__(self):
        self.instruction_limit = 2
        self.instruction_list = []
        self.preissbuffer = PreIssB.PreIssueBuffer()
        self.premem = PreMem.PREMEM()
        self.prealu = PreAlu.PREALU()
        self.cycle = 0

    def connectPreIssBuf(self, pib, pm, pa):
        self.preissbuffer = pib
        self.premem = pm
        self.prealu = pa

    def getpreissuebuffer(self):
        return PreIssB.prebuffer_entries[0]

    def checkinstructionhazard(self, instructionstr):
        pass
        return True

    def scanpreissuebuffer(self):
        for e in self.preissbuffer.prebuffer_entries:
            if not self.checkinstructionhazard(e):
                index = self.preissbuffer.prebuffer_entries.index(e)
                self.preissbuffer.IssueInstruction(index)

    def nextclockcycle(self):
        count = self.preissbuffer.AvailablePreBuffer()
        for i in range(count):
            self.instruction_list.append(self.preissbuffer.issueinstruction())
