import sys


class SetUp:

    def __init__(self):
        pass
    inputFileName = ''
    outputFileName = ''
    instructions = ''

    # TODO  Input/output for Simulator ?
    @classmethod
    def get_input_filename(cls):
        global inputFileName
        for i in range(len(sys.argv)):
            if sys.argv[i] == '-i' and i < (len(sys.argv) - 1):
                inputFileName = sys.argv[i+1]
        return inputFileName

    @classmethod
    def get_output_filename(cls):
        global outputFileName
        for i in range(len(sys.argv)):
            if sys.argv[i] == '-o' and i < (len(sys.argv) - 1):
                outputFileName = sys.argv[i + 1]
        return outputFileName

    @classmethod
    def import_data_file(cls):
        global instructions, inputFileName
        for i in range(len(sys.argv)):
            if sys.argv[i] == '-i' and i < (len(sys.argv) -1):
                inputFileName = sys.argv[i + 1]
        try:
            instructions = [line.rstrip() for line in open(inputFileName, 'r')]
        except IOError:
            print("Could not open input file, is path correct?")
        return instructions

    @classmethod
    def imm_bit_to_32_bit_converter(cls, num, bitsize):

        if bitsize < 32:
            negBitMask = 0x800       # 12 bit & mask
            extendMask = 0xFFFFF000  # 12 bit extend mask
            negBitMask2 = 0x2000000  # 26 bit & mask
            extendMask2 = 0xFF000000  # 26 bit extend mask
            negBitMask3 = 0x40000   # 19 bit & mask
            extendMask3 = 0xFFF80000 # 19 bit to 32 extend mask

            if bitsize == 12:       # I dont really need these masks, but after doing all the work, I left it
                if (negBitMask & num) > 0: # if negative
                    num = num | extendMask # extend 1s
                    num = num ^ 0xFFFFFFFF # flip bits
                    num = num + 1 # add 1
                    num = num * -1 # add negative sign
                    num = SetUp.imm_32_bit_unsigned_to_32_bit_signed_converter(num)  # And just undo it all here
            elif bitsize == 26:
                if (negBitMask2 & num) > 0:
                    num = num | extendMask2  # extend 1's
                    num = num ^ 0xFFFFFFFF  # flip bits
                    num = num + 1  # add 1
                    num = num * -1  # add negative sign
                    # num = SetUp.imm_32_bit_unsigned_to_32_bit_signed_converter(num) # Dont' convert, number is signed
            elif bitsize == 19:
                if(negBitMask3 & num) > 0:
                    num = num | extendMask3
                    num = num ^ 0xFFFFFFFF
                    num = num + 1
                    num = num * -1
                    # num = SetUp.imm_32_bit_unsigned_to_32_bit_signed_converter(num) # Number is signed, dont convert
            else:
                num = num | 0x0000
                num = SetUp.imm_32_bit_unsigned_to_32_bit_signed_converter(num)
        elif bitsize == 32:
            negMask32 = 0x10000000
            if (negMask32 & num) > 0:
                num = num ^ 0xFFFFFFFF
                num = num + 1
                num = num * -1
        else:
            print("You are using an invalid bit length")

        return num

    # @classmethod
    # def immSignedToTwosConverter(cls, num):
    # Function isn't needed

    @classmethod
    def bin2StringSpaced(cls, s):
        spacedStr = s[0:8] + " " + s[8:11] + " " + s[11:16] + " " + s[16:21] + " " + s[21:26] + " " + s[26:32]
        return spacedStr

    @classmethod
    def bin2StringSpacedD(cls, s):
        spacedStr = s[0:11] + " " + s[11:20] + " " + s[20:22] + " " + s[22:27] + " " + s[27:32]
        return spacedStr
        #test

    @classmethod
    def bin2StringSpacedIM(cls, s):
        spacedStr = s[0:9] + " " + s[9:11] + " " + s[11:27] + " " + s[27:32]
        return spacedStr
        #Test

    @classmethod
    def bin2StringSpacedCB(cls, s):
        spacedStr = s[0:8] + " " + s[8:27] + " " + s[27:32]
        return spacedStr
        # Test

    @classmethod
    def bin2StringSpacedI(cls, s):
        spacedStr = s[0:10] + " " + s[10:22] + " " + s[22:27] + " " + s[27:32]
        return spacedStr
        # Test

    @classmethod
    def bin2StringSpacedR(cls, s):
        spacedStr = s[0:11] + " " + s[11:16] + " " + s[16:22] + " " + s[22:27] + " " + s[27:32]
        return spacedStr
        # Test

    @classmethod
    def bin2StringSpacedB(cls, s):
        spacedStr = s[0:6] + " " + s[6:32]
        return spacedStr
        # Test

    @classmethod
    def imm_32_bit_unsigned_to_32_bit_signed_converter(cls, num):
        signedNum = num & 0xFFFFFFFF
        return signedNum

    @classmethod
    def decimalToBinary(cls, num):
        # Converts decimal num to binary and print
        if num > 1:
            cls.decimalToBinary(num // 2)
        print(num % 2, end='')

    @classmethod
    def binaryToDecimal(cls, binary):
        print("\n")
        print(int(binary, 2))

