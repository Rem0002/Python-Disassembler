import POSTMEM
import PreMem
import cache


class MemUnit:
    def __init__(self):
        self.isstalled = False
        self.locations = []
        self.max_entries = 0
        self.prememunit = PreMem.PREMEM()
        self.postmemunit = POSTMEM.PostMem()
        self.cache = Cache.Cache()
        self.cycle = 0

    def connectunits(self, prem, postm, c):
        self.prememunit = prem
        self.cache = c
        self.postmemunit = postm

    def HandleLDURInstruction(self):
        pass
        # TODO - check cache (wait for next cycle on miss) check for availability of the source register in ALU, mem,
        #  and writeback

    def HandleSTURInstruction(self):  # check to ensure no writes are being done to addresses on wrong side of
        pass
        # TODO - check for room in cache (retry on next cycle if full); completes here and not passed to WB; may have to
        #  check for raw hazard and ensure that currently running oeprations don't constitute problem

    def CheckRawHazard(self):  # compare arg1 in PC with arg2 and arg3 for PC + 4 and PC + 8
        pass

    def