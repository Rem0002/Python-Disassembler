import MEMUNIT
import WB

class PostMem:
    def __init__(self):
        self.isstalled = False
        self.entries = []
        self.max_entries = 1
        self.Memunit = MEMUNIT.MemUnit()
        self.wbu = WB.WBUnit
        self.cycle = 0

    def connectunits(self, MemUnit, wb):
        self.memunit = MemUnit
        self.wbu = wb
