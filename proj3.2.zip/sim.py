import WB
import ALU
import MEMUNIT
import IssueUnit
import IFPy
import PC
from cache import Cache
from Registers import registers

global_cycle = 0


class Sim:
    def __init__(self, instructions, opcodes, opcodeStr, dataval, address, arg1, arg2, arg3, arg1Str, arg2Str, arg3Str,
                 numInstructions, destReg, src1Reg, src2Reg):
        self.instructions = instructions
        self.opcodes = opcodes
        self.dataval = dataval
        self.address = address
        self.numInstructions = numInstructions
        self.arg1 = arg1
        self.arg2 = arg2
        self.arg3 = arg3
        self.arg1Str = arg1Str
        self.arg2Str = arg2Str
        self.arg3Str = arg3Str
        self.destReg = destReg
        self.src1Reg = src1Reg
        self.src2Reg = src2Reg
        self.opcodeStr = opcodeStr
        self.PC = 96
        self.cycle = 1
        self.cycleList = [0]
        self.R = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        self.postMemBuff = [-1, -1]
        self.postALUBuff = [-1, -1]
        self.preMemBuff = [-1, -1]
        self.preALUBuff = [-1, -1]
        self.preIssueBuff = [-1, -1, -1, -1]

        self.WB = WB.WriteBack(self.R, self.postMemBuff, self.postALUBuff, destReg)
        self.cache = Cache(numInstructions, instructions, dataval, address)
        self.ALU = ALU.ALU(self.R, self.postALUBuff, self.preALUBuff, opcodeStr, arg1, arg2, arg3)
        self.MEM = MEMUNIT.Memory(self.R, self.postMemBuff, self.preMemBuff, opcodeStr, arg1, arg2, arg3, dataval, address, self.numInstructions, self.cache, self.cycleList)
        self.issue = IssueUnit.Issue(instructions, opcodeStr, dataval, address, arg1, arg2, arg3, self.numInstructions, destReg, src1Reg, src2Reg, self.R, self.preIssueBuff, self.preMemBuff, self.postMemBuff, self.preALUBuff, self.postALUBuff)
        self.fetch = IFPy.Fetch(instructions, opcodeStr, dataval, address, arg1, arg2, arg3, self.numInstructions, destReg, src1Reg, src2Reg, self.R, self.preIssueBuff, self.preMemBuff, self.postMemBuff, self.preALUBuff, self.postALUBuff, self.PC, self.cache)

        # self.OutputFilename = SetUp.get_output_filename

    def run(self):

def main():
    pass
    # set up the simulator and run
    # sim = Sim()


if __name__ == "__main__":
    main()
