import IssueUnit
import ALU


class PREALU:


    def __init__(self):
        self.isstalled = False
        self.queue = []
        self.max_entries = 2
        self.issueunit = IssueUnit.IssueUnit()
        self.ALU = ALU.ALU

    def connect(self, iss):
        self.issueunit = iss
        # self.alu = ALU.ALU

    def getinstruction(self):
        hold = ""
        if len(self.queue) > 0:
            hold = self.queue[0]
            self.queue.remove(hold)
        return hold

    def addinstruction(self,e):
        if len(self.queue) == 2:
            self.isstalled = True # opt
        else:
            self.queue.append(e)

    def isprealufull(self):
         if len(self.queue) == 2:
             return True
         else:
             return False

    def checkrawhazard(self):
        if self.queue[0]
