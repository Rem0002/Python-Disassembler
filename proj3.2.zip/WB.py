import POSTMEM
from PostALU import postAlu
import sim
from Registers import registers

class WriteBack:

    # self.WB = WB.WriteBack(self.R, self.postMemBuff, self.postALUBuff, destReg)
    def __init__(self, R, postMembuff, postALUBuff, destReg):
        self.R = R
        self.postMembuff = postMembuff
        self.postALUBuff = postALUBuff
        self.writeback_entries = []
        self.destReg = destReg
        # self.max_writebacks = 2
        self.postalu = PostALU.PostALU()
        self.postmem = POSTMEM.PostMem()
        self.cycle = 0

    def connect(self, pm, pa):
        self.postmem = pm
        self.postalu = pa

    def process(self):
        self.fetchpostalu()
        self.fetchpostmem()
        for i in self.writeback_entries:
            register, value = i
            self.write_to_register(register, value)
        self.writeback_entries = []

    def fetchpostalu(self):
        # self.writeback_entries.append(self.postalu.pull())

    # def writepostalu(self):
        # PostALU.entry = []

    def fetchpostmem(self):
        # self.writeback_entries.append(self.postmem)

    # def writepostmem(self):
        # POSTMEM.entries = []

    def write_to_register(self, register, value):
        registers[register] = value


