registers = dict()
for i in range(32):
    registers[f'r{i}'] = 0


