import PreIssB
import cache
import PC
import disassembler


class IF:
    def __init__(self):
        self.isstalled = False
        self.instructions = []

        self.clockcycle = 0
        self.fetchlimit = 2
        self.fetchcount = 0
        self.prebuffer = PreIssB.PreBuffer()
        self.cache = cache.Cache()
        self.PC = PC.PC

    def connectunits(self, preb, c, pc):
        self.prebuffer = preb
        self.cache = c
        self.PC = PC.PC

    def connect_prebuffer(self, prebuffer):
        self.prebuffer = prebuffer

    def checkstalledstatus(self):
        self.fetchcount = self.checkprebuffer()
        if self.fetchcount == 0:
            self.isstalled = True
        else:
            self.isstalled = False
        return False

    def checkprebuffer(self):
        fcount = 0  # instructions to fetch  from prebuffer - how many
        # count = call prebuffer function yet to be defined
        return fcount

    def fetchfromcache(self, fcount):
        count = 0
        if self.isstalled:
            pass
        else:
            while count < fcount or self.isstalled:
                pass
                # fetch instruction
                # if branch instruction  set isstalled to true
                # decode
                count += 1

    def decode(self):
        pass

    def nextclockcycle(self):
        if not self.isstalled:
            self.fetchcount = self.PreB.PreBuffer.availableprebuffer()
            if self.fetchcount == 2:
                self.fetchfromcache(0)
            elif self.fetchcount == 1:
                self.fetchfromcache(0)
