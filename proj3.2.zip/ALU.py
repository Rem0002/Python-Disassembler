import PreAlu
from PostALU import postAlu
from disassembler import Disassembler
from Registers import registers

class ALU:
    def __init__(self, R, postALUBuff, preALUBuff, arg1, arg2, arg3):
        self.prealu = PreAlu.PREALU()
        self.postalu = PostALU.PostALU()
        self.cycle = 0
        self.disassembler = Disassembler()
        self.arg1 = arg1
        self.arg2 = arg2
        self.arg3 = arg3

    def connect(self, prea, posta):
         self.prealu = prea
         self.postalu = posta

    def fetchprealubuffer(self):
        connect(self, self.prealu, self.postalu)
        return_element = self.prealu.queue[0]
        self.prealu.queue.pop(0)
        return return_element

    def processinstruction(self):  # do the math on instruction using opcode checks
        data = self.disassembler.run(self.prealu.queue[:1])["register"]
        postAlu.push(data)
        # send register and result to postALU registers[register] = result

        # self.postalu.push(register, result)

    def ALUCheckRawHazard(self):
        return self.prealu.queue[1].arg2 or self.prealu.queue[1].arg3 == self.prealu.queue[0].arg1

    def handleADDinstr(self):
        pass